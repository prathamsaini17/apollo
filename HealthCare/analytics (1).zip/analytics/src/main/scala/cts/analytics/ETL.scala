package cts.analytics

import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import scala.collection.mutable.ListBuffer
import scala.collection.mutable.ArrayBuffer 
import org.apache.spark.sql.types._;

/*
spark-submit --class "cts.analytics.ETL" --master local[*] --jars /usr/share/java/mysql-connector-java.jar ETL.jar \
localhost analyticsdb masterdata cdh cdh-123 2 3 \
Address.HouseNo,Address.Address1,Address.Address2,Address.City,Address.PinCode,Contact.Mobile quickstart.cloudera /user/cloudera/customETL 
*/

object ETL {
  def main(args: Array[String]) {
    Logger.getLogger("org").setLevel(Level.ERROR)

    val spark = SparkSession
            .builder()
            .appName("cts.analytics.ETL")
            .enableHiveSupport()
            .getOrCreate() 
  
   val FinalRowList = new ListBuffer[List[String]]()         
   var FinalList = spark.sparkContext.broadcast(FinalRowList)
   
   import spark.sqlContext.implicits._ 
   
   val MySqlTable = spark.sqlContext.read.format("jdbc").option("url", "jdbc:mysql://"+args(0)+"/"+args(1)).
                     option("driver", "com.mysql.jdbc.Driver").option("dbtable", args(2)).
                     option("user", args(3)).option("password", args(4)).load()  
                     
   MySqlTable.registerTempTable("MySqlTable")
   
   var ColHeader = MySqlTable.columns
   val ColCount = MySqlTable.columns.length
   var FinalColNames = ArrayBuffer[String]()
   var FinalColsDone = 0
   
   MySqlTable.collect().foreach(row => {
        var DataList = new ListBuffer[String]()
       	for (Counter <- 0 to (ColCount-1)) {
       	  if (Counter == (args(5).toInt-1)){
       	    if ((row.get((args(6).toInt-1)).toString().toInt) == 0){
       	      DataList = FormatXML(scala.xml.XML.loadString(row.get((args(5).toInt-1)).toString()),DataList,args(7))
       	    }
       	    else
       	    {
       	      DataList = FormatJSON(row.get((args(5).toInt-1)).toString(),DataList,args(7))
       	    }
       	    
       	    if(FinalColsDone == 0){FinalColNames = FinalColNames ++ args(7).split(',')}
       	  }
       	  else
       		{DataList += row.get(Counter).toString();if(FinalColsDone == 0){FinalColNames += ColHeader(Counter)}}
       	}
        val RowList = FinalList.value
        RowList += DataList.toList
        FinalList = spark.sparkContext.broadcast(RowList)
        FinalColsDone = FinalColsDone+1
        })
   
    //println (FinalList.value)
    //println(FinalColNames.toArray.mkString(","))
    
    val FinalColNames_ = FinalColNames.toArray
    var Schema = ArrayBuffer[StructField]()
    for (Counter <- 0 to (FinalColNames_.length-1)) {
      Schema += StructField(FinalColNames_(Counter), StringType, false)
    }
    val SchemaFinal = StructType(Schema.toArray)    
    
    val rdd = spark.sqlContext.sparkContext.parallelize(FinalList.value)
    val rowRdd = rdd.map(v => Row(v: _*))

    var FinalDF = spark.sqlContext.createDataFrame(rowRdd,SchemaFinal)
  
    FinalDF
    .coalesce(1)
    .write   
    .format("com.databricks.spark.csv")
    .option("header", "true")
    .mode("overwrite")
    .save("hdfs://" + args(8) + ":8020" + args(9)) 
    
    FinalDF.show()
  }

  def FormatXML(XML: scala.xml.Elem, DataList: ListBuffer[String], Columns : String) : ListBuffer[String] = {
    val ColumnsList = Columns.split(',')
    
    for(Counter <- 0 to (ColumnsList.length-1)){
      DataList += ((XML \\ ColumnsList(Counter).split('.')(0)) \ ColumnsList(Counter).split('.')(1)).text
    }
    
    return DataList
  }
  
  def FormatJSON(JSONData : String, DataList: ListBuffer[String], Columns : String) : ListBuffer[String] = {
     val result = scala.util.parsing.json.JSON.parseFull(JSONData)
     val ColumnsList = Columns.split(',')

    for(Counter <- 0 to (ColumnsList.length-1)){
      var Matched = 0
      
       result match {
        case Some(e:Map[String,String]) => {
          e.foreach { pair => 
            if(ColumnsList(Counter).split('.')(1) == pair._1)
            {
              DataList += pair._2
              Matched = 1
              }
          }
        }
        case None => println("Failed.")
      }
      
      if(Matched == 0){DataList += ""}
    }
      
    return DataList
  }
}