package cts.analytics

import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.storage.StorageLevel._

object BatchLayer_FMCG {
  
val run = """
spark-submit --class "cts.analytics.BatchLayer_FMCG" --master local[*] --jars hive-hbase-handler-2.1.1.jar \
BatchLayer_FMCG.jar quickstart.cloudera /user/fmcg/transaction/orders/hot/*/* /user/fmcg/transaction/orderdetails/hot/*/* 
"""  
  
  case class order(orderid: Int, customerid: Int, orderdate: java.sql.Timestamp)

  def ordermapper(line: String): order = {
    val format = new java.text.SimpleDateFormat("yyyy-MM-dd")
    val fields = line.split(',')
    val ord: order = order(fields(0).toInt, fields(1).toInt,
      new java.sql.Timestamp(format.parse(fields(3)).getTime()))
    return ord
  }

  case class orderdetails(orderid: Int, productid: Int, quantity: Int)

  def orderdetailsmapper(line: String): orderdetails = {
    val fields = line.split(',')
    val od: orderdetails = orderdetails(fields(0).toInt, fields(1).toInt, fields(3).toInt)
    return od
  }
  
  def main(args: Array[String]) {
    Logger.getLogger("org").setLevel(Level.ERROR)

    val SparkConf = new SparkConf().setAppName("cts.analytics.FMCG.BatchLayer")
    val spark = SparkSessionSingleton.getInstance(SparkConf)
    import spark.implicits._
  
    val lines = spark.sparkContext.textFile("hdfs://"+args(0)+":8020"+args(1))
    val lines1 = spark.sparkContext.textFile("hdfs://"+args(0)+":8020"+args(2))
    lines.persist(MEMORY_AND_DISK)
    
    val orders = lines.map(ordermapper)
    
    val Orders = orders.toDF()
    Orders.printSchema()

    Orders.createOrReplaceTempView("orders");

    val orderdetails = lines1.map(orderdetailsmapper)
    orderdetails.persist(MEMORY_AND_DISK)
    
    val Orderdetails = orderdetails.toDF()
    Orderdetails.printSchema()
    Orderdetails.createOrReplaceTempView("orderdetails");

    val hivetable = spark.table("fmcg.hb_products")
    hivetable.createOrReplaceTempView("products");
    
    val hivetable1 = spark.table("fmcg.hb_customers")
    hivetable1.createOrReplaceTempView("customers");

    val orderhabit = spark.sql("select p.productname, o.orderdate, od.Quantity from orders as o join orderdetails as od using(orderid) join products as p using(productid) order by o.OrderDate");
    println("Question 01 of Batch Layer - This shows Ordering Habits of Customer.")
    orderhabit.show()    
    
    val frequencyOrder = spark.sql("select p.productname, concat(c.customerfname,' ',c.customerlname) as customername, OrderDate from products as p join orderdetails as od using(productid) join orders as o using(orderid) join customers as c using(customerid) order by c.CustomerFName");
    println("Question 02 of Batch Layer - This shows FREQUENCY OF ORDERS Of Customers.")
    frequencyOrder.show()
    
    val freqencyReOrder = spark.sql("select p.productname, o.OrderDate, count(p.ProductName) as count, c.CustomerFName from products as p join orderdetails as od using(productid) join orders as o using(orderid) join customers as c using(customerid) group by c.CustomerFName,o.OrderDate,p.ProductName order by c.CustomerFName");
    println("Question 03 of Batch Layer - This shows FREQUENCY OF REORDERS Of Customers.")
    freqencyReOrder.show()
    
    spark.stop()
  }    
}