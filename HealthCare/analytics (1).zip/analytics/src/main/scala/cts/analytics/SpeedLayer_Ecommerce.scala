package cts.analytics

import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.apache.log4j._
import org.apache.spark.sql.functions._
import org.apache.spark.streaming._

object SpeedLayer_Ecommerce {

/*
while read line; do echo -e "$line\n"; sleep .1; done < ordersfeed2.csv | nc -lk 9992

spark-submit --class "cts.analytics.SpeedLayer_Ecommerce" --master local[*] --jars hive-hbase-handler-2.1.1.jar \
SpeedLayer_Ecommerce.jar 1 localhost 9992 10 50 10 5 quickstart.cloudera /user/ecommerce/apriori

========================================

while read line; do echo -e "$line\n"; sleep .01; done < usertrafficdata.csv | nc -lk 9992

spark-submit --class "cts.analytics.SpeedLayer_Ecommerce" --master local[*] --jars hive-hbase-handler-2.1.1.jar \
SpeedLayer_Ecommerce.jar 0 localhost 9992 5 40 10 20
*/

  def main(args: Array[String]) {
    Logger.getLogger("org").setLevel(Level.ERROR)
  
    val sparkConf = new SparkConf().setAppName("cts.analytics.Ecommerce.SpeedLayer")
    val sc = new StreamingContext(sparkConf, Seconds(args(3).toInt))
    sc.checkpoint("/tmp/Ecommerce");

    val datastream = sc.socketTextStream(args(1), args(2).toInt, StorageLevel.MEMORY_AND_DISK_SER)
    
    if(args(0).toInt == 0)
    {
      val ChannelDStream =  datastream.map(generic_mapper2).filter(t => (t._1 != "NA"))  

      val TrafficSpikeWindow =
          		ChannelDStream.reduceByKeyAndWindow((a:Int,b:Int) => (a + b),(a:Int,b:Int) => (a - b),
          		    Durations.seconds(args(4).toInt), Durations.seconds(args(5).toInt))
      TrafficSpikeWindow.foreachRDD 
      { 
        (rdd, time) =>
          if(!rdd.isEmpty()){        
            val spark = SparkSessionSingleton.getInstance(rdd.sparkContext.getConf)
            import spark.implicits._
      
            val TrafficSpikeDF = rdd.toDF("Channel","Hits")
            TrafficSpikeDF.createOrReplaceTempView("TrafficSpike")
      
            val TrafficSpike =
              spark.sql("select Channel,round(("+args(6)+"-((Hits*100)/(select sum(Hits) from TrafficSpike))),2) as Spike from TrafficSpike order by Spike desc")
                
            println(s"=== Spike Above Threshold ("+args(6)+"%) === [ $time ] === [ Window Length : "+
                args(4)+" Seconds / Slide Interval : "+args(5)+" Seconds ] ===")
            
            TrafficSpike.select(TrafficSpike("Channel"),TrafficSpike("Spike")).show(false)   
        }
      }
      
      def Channel(newData: Seq[Int], state: Option[Int]) = {
        val newState = state.getOrElse(0) + newData.sum
        Some(newState)
      }
      val ChannelFinalDStream = ChannelDStream.updateStateByKey(Channel)
      ChannelFinalDStream.foreachRDD 
      { 
        (rdd, time) =>
          if(!rdd.isEmpty()){        
            val spark = SparkSessionSingleton.getInstance(rdd.sparkContext.getConf)
            import spark.implicits._
      
            val ChannelDF = rdd.toDF("Channel","Hits")
            ChannelDF.createOrReplaceTempView("Channel")
      
            val Channel =
              spark.sql("select * from Channel order by Hits desc limit 5")
                
            println(s"=== Most Hits OverAll === [ $time ] === [ Top 5 ] ===")
            
            Channel.select(Channel("Channel"),Channel("Hits")).show(false)   
        }
      }    
    }
    
    if(args(0).toInt == 1)
    {
      val spark = SparkSessionSingleton.getInstance(sc.sparkContext.getConf)
      import spark.implicits._ 
      
      val ProductsDF = spark.table("ecommerce.hb_products").rdd.
      map(f => (f.get(0).toString().toInt,(f.get(2).toString()+"_"+f.get(1).toString(),f.get(3).toString().toInt)))
      ProductsDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
           
      val mapdatatopair =  datastream.map(generic_mapper).filter(t => (t._1 != -1))   
      val takerelevantdata = mapdatatopair.transform { rdd => rdd.join(ProductsDF).map(model_mapper) } 
  
      takerelevantdata.foreachRDD 
      { 
        (rdd, time) =>
          if(!rdd.isEmpty()){
            val spark = SparkSessionSingleton.getInstance(rdd.sparkContext.getConf)
            import spark.implicits._
      
            val AprioriBaseDF  = rdd.toDF()
            AprioriBaseDF.createOrReplaceTempView("AprioriBase")
            val Apriori = spark.sql("""
              select OrderID,concat_ws(',', collect_list(distinct(ProductName))) As Order_Items 
              from AprioriBase 
              group by OrderID
              """)
            
            println(s"=== Apriori Feed === [ $time ] === [ Batch Size : "+args(3)+" Seconds ] ===")
            
            Apriori.select(Apriori("Order_Items")).show(false)
            def uuid = java.util.UUID.randomUUID.toString
            Apriori.select(Apriori("Order_Items")).
            map(t => "%s".format(t.get(0).toString())).
            write.
            format("com.databricks.spark.csv").
            option("header", false).
            option("delimiter", "\t").
            save("hdfs://"+args(7)+":8020"+args(8)+"/"+uuid)          
        }
      }    
  
      val ConsumptionPattern = takerelevantdata.transform { rdd =>
        {
          val spark = SparkSessionSingleton.getInstance(rdd.sparkContext.getConf)
          import spark.implicits._ 
  
          val ConsumptionPatternDF = rdd.toDF()
          ConsumptionPatternDF.createOrReplaceTempView("ConsumptionPattern")
    
          val ConsumptionPattern_1 =
            spark.sql("""
              select ProductName,CONCAT(UnitsInStock, "_", sum(Quantity)) AS Consumption from ConsumptionPattern
              group by ProductName,UnitsInStock     
              """)
                  
          ConsumptionPattern_1.rdd.map(r => (r.getAs("ProductName").toString(),r.getAs("Consumption").toString()))
        }
      }          
      val ConsumptionPatternWindow =
          		ConsumptionPattern.reduceByKeyAndWindow(
          		    (a:String,b:String) => (a.split('_')(0)+"_"+(a.split('_')(1).toInt+b.split('_')(1).toInt).toString()),
          		    (a:String,b:String) => (a.split('_')(0)+"_"+(a.split('_')(1).toInt-b.split('_')(1).toInt).toString()),
          		    Durations.seconds(args(4).toInt), 
          		    Durations.seconds(args(5).toInt)
          		    )
      ConsumptionPatternWindow.foreachRDD 
      { 
        (rdd, time) =>
          if(!rdd.isEmpty()){        
            val spark = SparkSessionSingleton.getInstance(rdd.sparkContext.getConf)
            import spark.implicits._
      
            val ConsumptionPatternDF = 
              rdd.map(t => (t._1,t._2.split('_')(0).toInt,t._2.split('_')(1).toInt)).toDF("ProductName","UnitsInStock","Quantity")
            ConsumptionPatternDF.createOrReplaceTempView("ConsumptionPattern")
      
            val ConsumptionPercentage =
              spark.sql("""
                select ProductName,
                round(((Quantity*100)/UnitsInStock),2) as ConsumptionInPercent,
                CONCAT(round(((Quantity*100)/UnitsInStock),2), " % (", Quantity, "/", UnitsInStock, ")") as Consumption 
                from ConsumptionPattern 
                order by ConsumptionInPercent desc limit """+args(6))
                
            println(s"=== Fast Depleting Stock (Top "+args(6)+") === [ $time ] === [ Window Length : "+args(4)+" Seconds / Slide Interval : "+args(5)+" Seconds ] ===")
            
            ConsumptionPercentage.select(ConsumptionPercentage("ProductName"),ConsumptionPercentage("Consumption")).show(false)   
        }
      }
    }
    
    sc.start()
    sc.awaitTermination()      
  }
  
  case class Feed(ProductID:Int, ProductName:String, UnitsInStock:Int, OrderID:Int, Quantity:Int, UnitPrice:Double)

  def model_mapper(T:(Int,((Int,Int,Double),(String,Int)))): Feed = {
    val feed:Feed = Feed(T._1,T._2._2._1,T._2._2._2,T._2._1._1,T._2._1._2,T._2._1._3)
        
    return feed
  }
  
  def generic_mapper(line:String) = {
    val fields = line.split(',')
    if(fields.length == 4 && fields(0) != "OrderID"){(fields(1).toInt,(fields(0).toInt,fields(2).toInt,fields(3).toDouble))}
    else{(-1,(0,0,0.0))}
  } 
  
  def generic_mapper2(line:String) = {
    val fields = line.split(',')
    if(fields.length == 6 && fields(0) != "date"){(fields(2),1)}
    else{("NA",0)}
  }  
}