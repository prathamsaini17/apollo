package cts.analytics.Learn

import org.apache.spark.SparkConf
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.log4j._

//nc -lk 9999
//spark-submit --class "baci.sprk.Stream1" --master local str1.jar localhost 9999

object Stream1 {
  def main(args: Array[String]) {
    Logger.getLogger("org").setLevel(Level.ERROR)
    val sparkConf = new SparkConf().setAppName("Streaming Word Count")
    val ssc = new StreamingContext(sparkConf, Seconds(5))

    val lines = ssc.socketTextStream(args(0), args(1).toInt, StorageLevel.MEMORY_AND_DISK_SER)
    val words = lines.flatMap(_.split(" "))
    val wordCounts = words.map(x => (x, 1)).reduceByKey(_ + _)
    def uuid = java.util.UUID.randomUUID.toString
    wordCounts.saveAsTextFiles("hdfs://10.142.1.1:8020/user/contactrkk4095/sprk/"+uuid)
    wordCounts.print()
    ssc.start()
    ssc.awaitTermination()
  }
}
