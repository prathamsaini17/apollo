package cts.analytics

import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.apache.log4j._
import org.apache.spark.sql.functions._
import org.apache.spark.streaming._

object SpeedLayer_Aviation {

/*
while read line; do echo -e "$line\n"; sleep .1; done < flightfeed.csv | nc -lk 9990

spark-submit --class "cts.analytics.SpeedLayer_Aviation" --master local[*] SpeedLayer_Aviation.jar localhost 9990 5 60 5 750
*/

  case class Feed(FlightNo:String, DistanceCovered:Double, Humidity:Int, Temp:Int, Latitude:String, Longitude:String, AltitudeInFeet:Int)

  def model_mapper(T:(String,Double,Int,Int,String,String,Int)): Feed = {
    val feed:Feed = Feed(T._1,T._2,T._3,T._4,T._5,T._6,T._7)
        
    return feed
  }
  
  def generic_mapper(line:String) = {
    val fields = line.split(',')
    if(fields.length == 7){
      if(!fields(0).startsWith("flight_no"))
      {(fields(0),fields(1).toDouble,fields(2).toInt,fields(3).toInt,fields(4),fields(5),fields(6).toInt)}
      else{("NA",0.00,0,0,"NA","NA",0)}
      }
    else{("NA",0.00,0,0,"NA","NA",0)}
  }

  def main(args: Array[String]) {
    Logger.getLogger("org").setLevel(Level.ERROR)
  
    val sparkConf = new SparkConf().setAppName("cts.analytics.Aviation.SpeedLayer")
    val sc = new StreamingContext(sparkConf, Seconds(args(2).toInt))
    sc.checkpoint("/tmp/Aviation");
        
    val datastream = sc.socketTextStream(args(0), args(1).toInt, StorageLevel.MEMORY_AND_DISK_SER)     
     
    val mapdatatopair =  datastream.map(generic_mapper).filter(t => (t._1 != "NA"))   
        
    val RequiredDStream = mapdatatopair.transform { rdd =>
      {
        val spark = SparkSessionSingleton.getInstance(rdd.sparkContext.getConf)
        import spark.implicits._ 

        val FlightTravelDF = rdd.map(model_mapper).toDF()
        FlightTravelDF.createOrReplaceTempView("FlightTravel")
  
        val FlightTravel =
          spark.sql("""
            select 
            FlightNo,
            min(DistanceCovered) as ActualMin,            
            max(DistanceCovered) as ActualMax,
            (min(DistanceCovered)+(("""+args(5)+"""/3600)*"""+args(2)+""")) as PlannedMax,            
            (max(DistanceCovered)-min(DistanceCovered)) as ActualDiff,
            round(((min(DistanceCovered)+(("""+args(5)+"""/3600)*"""+args(2)+"""))-max(DistanceCovered)),2) as DiffBetweenPlannedAndActualMax
            from FlightTravel 
            group by FlightNo   
            """)
                
        FlightTravel.rdd
      }
    } 
    
    val FlightArrivalDStream = RequiredDStream.map(T => 
      (T.getAs("FlightNo").toString(),T.getAs("DiffBetweenPlannedAndActualMax").toString().toDouble))
    val FlightArrivalWindow =
        		FlightArrivalDStream.reduceByKeyAndWindow((a:Double,b:Double) => (a + b),(a:Double,b:Double) => (a - b),
        		    Durations.seconds(args(3).toInt), Durations.seconds(args(4).toInt))
    FlightArrivalWindow.foreachRDD 
    { 
      (rdd, time) =>
        if(!rdd.isEmpty()){        
          val spark = SparkSessionSingleton.getInstance(rdd.sparkContext.getConf)
          import spark.implicits._
    
          val FlightArrivalDF = rdd.toDF("Flight","Delay")
          FlightArrivalDF.createOrReplaceTempView("FlightArrival")
    
          val FlightArrival =
            spark.sql("select * from FlightArrival order by Delay desc")
              
          println(s"=== Flight Arrival === [ $time ] === [ Window Length : "+args(3)+" Seconds / Slide Interval : "+args(4)+" Seconds ] ===")
          
          FlightArrival.select(FlightArrival("Flight"),FlightArrival("Delay")).show(false)   
      }
    }
        
    sc.start()
    sc.awaitTermination()      
  }
}