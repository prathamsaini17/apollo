package cts.analytics

import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.storage.StorageLevel._

object BatchLayer_Ecommerce 
{

val run = """
spark-submit --class "cts.analytics.BatchLayer_Ecommerce" --master local[*] --jars hive-hbase-handler-2.1.1.jar \
BatchLayer_Ecommerce.jar quickstart.cloudera /user/ecommerce/transaction/orders/hot/*/* /user/ecommerce/transaction/order_details/hot/*/* 
"""  
  
  case class orders(orderID:Int, orderDate:java.sql.Timestamp)
  case class orderdetails(orderID:Int, productID:Int)

  def ordersmapper(line:String): orders = {
    val format = new java.text.SimpleDateFormat("yyyy-MM-dd")
    val fields = line.split(',')    
    val _orders:orders = orders(fields(0).toInt, new java.sql.Timestamp(format.parse(fields(1)).getTime()))
    return _orders
  }
  
  def orderdetailsmapper(line:String): orderdetails = {
    val fields = line.split(',')    
    val od:orderdetails = orderdetails(fields(0).toInt, fields(1).toInt)
    return od
  }
  
  def main(args: Array[String]) 
  {
    Logger.getLogger("org").setLevel(Level.ERROR)

    val SparkConf = new SparkConf().setAppName("cts.analytics.Ecommerce.BatchLayer")
    val spark = SparkSessionSingleton.getInstance(SparkConf)
    import spark.implicits._

    val orders_lines = spark.sparkContext.textFile("hdfs://"+args(0)+":8020"+args(1))
    val order_details_lines = spark.sparkContext.textFile("hdfs://"+args(0)+":8020"+args(2))
    orders_lines.persist(MEMORY_AND_DISK)    
    order_details_lines.persist(MEMORY_AND_DISK)
 
    val ordersdf = orders_lines.map(ordersmapper).toDF()    
    val order_detailsdf = order_details_lines.map(orderdetailsmapper).toDF()   
    val productsdf = spark.table("ecommerce.hb_products")    
    ordersdf.createOrReplaceTempView("orders")
    order_detailsdf.createOrReplaceTempView("orderdetails")
    productsdf.createOrReplaceTempView("products");    
    ordersdf.show()
    order_detailsdf.show()
    productsdf.show()
    val Q1 = spark.sql("""
      select distinct p.productid,p.productname 
      from orderdetails od join orders o on o.orderID=od.orderID 
      join products p on p.productid=od.productID where year(o.orderDate) <= 2020""");
    Q1.show()

    val Q2 = spark.sql("""
      Select p.Category as Category, count(od.productID) as ProductCount 
      from products p join orderdetails od 
      on p.productID = od.productID group by p.Category 
      order by ProductCount desc limit 10""");
    Q2.show()
    
    spark.stop()
  }
}