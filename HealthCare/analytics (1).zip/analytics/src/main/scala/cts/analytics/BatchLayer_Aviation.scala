package cts.analytics

import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.storage.StorageLevel._

object BatchLayer_Aviation {
  
/*
spark-submit --class "cts.analytics.BatchLayer_Aviation" --master local[*] BatchLayer_Aviation.jar
*/
  
  def main(args: Array[String]) {
    Logger.getLogger("org").setLevel(Level.ERROR)

    val SparkConf = new SparkConf().setAppName("cts.analytics.Aviation.BatchLayer")
    val spark = SparkSessionSingleton.getInstance(SparkConf)
    import spark.implicits._
  
    val dwDF1 = spark.table("aviation.flighthistory")
    dwDF1.persist(MEMORY_AND_DISK)
    dwDF1.createOrReplaceTempView("flighthistory");  

    val dwDF2 = spark.table("aviation.travelhistory")
    dwDF2.persist(MEMORY_AND_DISK)
    dwDF2.createOrReplaceTempView("travelhistory"); 
    
    spark.sql("SET hive.mapred.supports.subdirectories=true");
    spark.sql("SET mapreduce.input.fileinputformat.input.dir.recursive=true");
    spark.sql("select  flightID ,avg(vacant) as month_vacant from flighthistory where substr(booking_date,6,8)=01 group by flightID order by month_vacant").show();    

    spark.sql("SET hive.mapred.supports.subdirectories=true");
    spark.sql("SET mapreduce.input.fileinputformat.input.dir.recursive=true");
    spark.sql("select  passid,count(travel_date) as No_of_travel from travelhistory group by passid order by  No_of_travel asc").show();    
       
    spark.stop()
  }    
}