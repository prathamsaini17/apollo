package cts.analytics

import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.storage.StorageLevel._

object BatchLayer_BFSI {
  
/*
spark-submit --class "cts.analytics.BatchLayer_BFSI" --master local[*] BatchLayer_BFSI.jar 60 60000
*/
  
  def main(args: Array[String]) {
    Logger.getLogger("org").setLevel(Level.ERROR)

    val SparkConf = new SparkConf().setAppName("cts.analytics.BFSI.BatchLayer")
    val spark = SparkSessionSingleton.getInstance(SparkConf)
    import spark.implicits._
  
    val dwDF = spark.table("bfsi.dw")
    dwDF.persist(MEMORY_AND_DISK)
    dwDF.createOrReplaceTempView("dw");  

    spark.sql("SET hive.mapred.supports.subdirectories=true");
    spark.sql("SET mapreduce.input.fileinputformat.input.dir.recursive=true");
    spark.sql("SELECT customer_id , first_name,account_number FROM dw WHERE datediff(CURRENT_DATE, Loan_last_paymentdate) >= "+args(0)).show();    

    spark.sql("SET hive.mapred.supports.subdirectories=true");
    spark.sql("SET mapreduce.input.fileinputformat.input.dir.recursive=true");
    spark.sql("Select  customer_id,First_name,account_number,current_balance from dw where current_balance >= "+args(1)).show();    
    
    spark.stop()
  }    
}